let inpt1;
let inpt2;

let radio;
let font1, font2;
let selectedFont;

let slider1;

let img1, img2, img3;
let selectedImage;

let rSlider;
let gSlider;
let bSlider;
let textColor;

function preload() {
  font1 = loadFont("ComicNeue-Regular.ttf");
  font2 = loadFont("Roboto-Black.ttf");

  img1 = loadImage("img1.jpeg");
  img2 = loadImage("img2.jpeg");
  img3 = loadImage("img3.png");
}

function setup() {
  createCanvas(400, 300);

  createP("Type title 1 here:");
  inpt1 = createInput("");

  createP("Type title 2 here:");
  inpt2 = createInput("");

  createP("Choose Font:");
  createRadioButtons();
  selectedFont = font1;

  createP("Change Font Size:");
  slider1 = createSlider(8, 35, 12);

  createP("Select an image:");
  let dropdown = createSelect();
  dropdown.option("Image 1");
  dropdown.option("Image 2");
  dropdown.option("Image 3");
  dropdown.changed(changeImage);

  createP("Change font colour(1):");
  rSlider = createSlider(0, 255, 50);

  createP("Change font colour(2):");
  gSlider = createSlider(0, 255, 50);

  createP("Change font colour(3):");
  bSlider = createSlider(0, 255, 100);

  textColor = color(127, 127, 127);
}

function draw() {
  background(255);

  let val1 = inpt1.value();
  let val2 = inpt2.value();

  let r = rSlider.value();
  let g = gSlider.value();
  let b = bSlider.value();
  textColor = color(r, g, b);
  fill(textColor);


  text(val1, 120, 50);
  text(val2, 120, 250);
  textFont(selectedFont);

  let val3 = slider1.value();
  textSize(val3);

  if (selectedImage) {
    image(selectedImage, 55, 55);
  }
}

function createRadioButtons() {
  let radio = createRadio();
  radio.option("Comic Neue");
  radio.option("Roboto");

  radio.selected("Comic Neue");
  radio.changed(changeFont);
}

function changeFont() {
  let val = this.value();
  if (val === "Comic Neue") {
    selectedFont = font1;
  } else if (val === "Roboto") {
    selectedFont = font2;
  }
}

function changeImage() {
  let selectedOption = this.value();
  if (selectedOption === "Image 1") {
    selectedImage = img1;
  } else if (selectedOption === "Image 2") {
    selectedImage = img2;
  } else if (selectedOption === "Image 3") {
    selectedImage = img3;
  }
}
